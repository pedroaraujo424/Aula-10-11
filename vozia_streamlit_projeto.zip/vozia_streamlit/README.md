# VozIA — Central de Chamadas Inteligente

Aplicação acadêmica em Streamlit que demonstra o fluxo de uma central telefônica digital:
- recebe uma transcrição de chamada;
- identifica sentimento aproximado e urgência;
- classifica a intenção e recomenda um setor;
- sugere uma resposta automática com base em FAQ;
- encaminha casos urgentes ou sem resposta segura para atendimento humano.

## Executar localmente

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Publicar no GitHub e Streamlit Community Cloud

1. Crie um repositório público no GitHub, por exemplo `vozia-central-inteligente`.
2. Envie `app.py`, `requirements.txt` e `README.md` para a raiz do repositório.
3. Acesse https://share.streamlit.io/ e entre com sua conta GitHub.
4. Selecione **New app**, escolha o repositório, branch `main` e arquivo `app.py`.
5. Clique em **Deploy**. A plataforma vai gerar uma URL para compartilhar.

## Limites importantes do protótipo

Esta é uma prova de conceito, não uma central telefônica de produção. A análise é feita por regras de palavras-chave e a transcrição deve ser colada pelo usuário. O upload de áudio serve apenas para demonstrar a entrada do arquivo: não realiza speech-to-text. Para produção, integrar um serviço de reconhecimento de fala, um modelo de linguagem, telefonia/SIP, CRM, autenticação, monitoramento e controles de privacidade. Casos sensíveis devem sempre permitir revisão e transferência para uma pessoa.

Não inserir gravações ou dados pessoais reais nesta demonstração.
