# Roteiro de apresentação — 5 minutos

## 0:00–0:40 | Problema
“Hoje, muitas empresas recebem um grande volume de chamadas com dúvidas repetitivas. Isso aumenta o tempo de espera, sobrecarrega os atendentes e pode dificultar a identificação de solicitações urgentes. A proposta da VozIA é tornar esse processo mais rápido e organizado.”

## 0:40–1:20 | Objetivo e solução
“A VozIA é um protótipo de central de chamadas inteligente. Ela recebe a transcrição de uma conversa, identifica o assunto e o sentimento aproximado do cliente, recomenda o setor responsável e sugere uma resposta automática. Quando não encontra uma resposta segura ou identifica urgência, recomenda transferir para um atendente.”

## 1:20–3:50 | Demonstração ao vivo
1. Abra o aplicativo e mostre os indicadores ilustrativos do topo. Explique que são números fictícios para compor a interface.
2. Selecione o exemplo **Financeiro — segunda via** e clique em **Analisar chamada**.
3. Mostre sentimento, setor, prioridade e resposta sugerida.
4. Em seguida, selecione **Suporte — acesso bloqueado**. Destaque que o sistema identifica urgência e recomenda escalonamento.
5. Se houver tempo, demonstre **Solicitar atendente**, reforçando que o cliente pode pedir atendimento humano.

Fala sugerida: “Em vez de o atendente interpretar tudo manualmente desde o início, o sistema já entrega uma primeira classificação e uma sugestão de resposta. Isso pode reduzir tarefas repetitivas e ajudar a equipe a priorizar os casos.”

## 3:50–4:30 | Como funciona
“O fluxo tem cinco etapas: entrada da transcrição, análise de palavras-chave, identificação da intenção, consulta à base de perguntas frequentes e decisão entre resposta automática ou encaminhamento. Nesta versão, as regras são locais e transparentes, o que facilita demonstrar o funcionamento.”

## 4:30–5:00 | Limitações e conclusão
“Este é um protótipo acadêmico. Ainda não realiza transcrição automática do áudio nem se conecta a uma linha telefônica ou CRM. Em uma próxima versão, podemos integrar speech-to-text, inteligência artificial generativa, telefonia e histórico do cliente, sempre com proteção de dados e opção de atendimento humano. A principal proposta é reduzir o tempo de atendimento, padronizar respostas e direcionar cada solicitação ao time correto. Obrigado!”

## Perguntas que podem fazer
**O sistema realmente escuta ligações?**  
Nesta versão, não. Ele analisa uma transcrição digitada ou colada. O upload de áudio é apenas demonstrativo. A transcrição automática seria uma integração futura com speech-to-text.

**Onde está a inteligência artificial?**  
O protótipo demonstra o fluxo de análise usando regras de palavras-chave. Em uma evolução, essas regras podem ser substituídas ou complementadas por um modelo de linguagem e classificação treinado/avaliado.

**E se o sistema errar?**  
A classificação é uma recomendação, não uma decisão definitiva. Casos urgentes, reclamações ou dúvidas sem resposta segura devem ser transferidos para um atendente.

**Quais seriam os benefícios?**  
Menor tempo em tarefas repetitivas, triagem mais rápida, respostas padronizadas e melhor priorização dos atendimentos.
