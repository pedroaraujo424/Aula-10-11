import streamlit as st
import re
from datetime import datetime

st.set_page_config(page_title="VozIA | Central inteligente", page_icon="☎️", layout="wide")

# ---------- Base de conhecimento e regras demonstrativas ----------
FAQ = [
    {"keys": ["segunda via", "boleto", "fatura"], "answer": "Você pode emitir a segunda via pelo aplicativo ou portal do cliente, na opção Financeiro > Faturas. Se preferir, posso encaminhar você ao setor financeiro.", "department": "Financeiro"},
    {"keys": ["senha", "bloqueado", "acesso"], "answer": "Para recuperar seu acesso, selecione 'Esqueci minha senha' na tela de login. Por segurança, nunca informe sua senha por telefone.", "department": "Suporte técnico"},
    {"keys": ["cancelar", "cancelamento"], "answer": "Posso registrar sua solicitação de cancelamento. Para concluir, é necessário validar seus dados com um atendente.", "department": "Retenção"},
    {"keys": ["entrega", "pedido", "rastreamento"], "answer": "Você pode acompanhar seu pedido na área 'Meus pedidos'. Caso o prazo tenha vencido, vou encaminhar sua solicitação ao time de logística.", "department": "Logística"},
    {"keys": ["humano", "atendente", "pessoa"], "answer": "Claro! Vou transferir você para um atendente. Aguarde um instante.", "department": "Atendimento humano"},
]
ROUTES = {
    "Financeiro": ["boleto", "fatura", "pagamento", "cobrança", "segunda via"],
    "Suporte técnico": ["senha", "sistema", "erro", "acesso", "internet", "login"],
    "Retenção": ["cancelar", "cancelamento", "reclamação", "insatisfeito"],
    "Logística": ["entrega", "pedido", "rastreamento", "atraso"],
}

def analyze(text):
    t = text.lower()
    urgency_words = ["urgente", "imediatamente", "parado", "sem acesso", "não consigo trabalhar", "fraude", "cobrança indevida"]
    negative_words = ["péssimo", "absurdo", "insatisfeito", "irritado", "problema", "reclamação", "demora", "não resolveu"]
    positive_words = ["obrigado", "obrigada", "ótimo", "excelente", "resolvido", "perfeito"]
    urgency = any(w in t for w in urgency_words)
    neg = sum(w in t for w in negative_words)
    pos = sum(w in t for w in positive_words)
    sentiment = "Negativo" if neg > pos else ("Positivo" if pos > neg else "Neutro")
    department = "Atendimento geral"
    best = 0
    for dept, words in ROUTES.items():
        score = sum(1 for w in words if w in t)
        if score > best:
            best, department = score, dept
    answer = "Não encontrei uma resposta automática segura. Vou direcionar sua chamada para um atendente."
    for item in FAQ:
        if any(k in t for k in item["keys"]):
            answer, department = item["answer"], item["department"]
            break
    if "humano" in t or "atendente" in t or "pessoa" in t:
        department = "Atendimento humano"
    priority = "Alta" if urgency or sentiment == "Negativo" else "Normal"
    return sentiment, department, priority, answer

st.markdown("""
<style>
.main {background: #f6f8fc;}
.block-container {padding-top: 1.6rem; max-width: 1200px;}
.hero {background: linear-gradient(110deg,#102447,#176b87); padding: 25px 28px; border-radius: 16px; color:white;}
.hero h1 {color:white; margin:0; font-size:2rem;}
.hero p {color:#e2f3f8; margin:.35rem 0 0 0;}
.metric {background:white; border:1px solid #e5eaf2; padding:16px; border-radius:12px;}
.small {color:#637083; font-size:.88rem;}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>☎️ VozIA — Central de Chamadas Inteligente</h1><p>Transcrição, análise de intenção e encaminhamento de atendimentos em um só lugar.</p></div>', unsafe_allow_html=True)
st.write("")
c1,c2,c3 = st.columns(3)
with c1: st.markdown('<div class="metric"><div class="small">CHAMADAS ANALISADAS</div><h2>1.284</h2><span class="small">Indicador ilustrativo</span></div>', unsafe_allow_html=True)
with c2: st.markdown('<div class="metric"><div class="small">RESOLUÇÃO AUTOMÁTICA</div><h2>68%</h2><span class="small">Indicador ilustrativo</span></div>', unsafe_allow_html=True)
with c3: st.markdown('<div class="metric"><div class="small">TEMPO MÉDIO</div><h2>2m 14s</h2><span class="small">Indicador ilustrativo</span></div>', unsafe_allow_html=True)

st.subheader("1. Simular uma chamada")
st.caption("Demonstração acadêmica: insira uma transcrição de exemplo. A análise usa regras locais e não envia dados para serviços externos.")
examples = {
    "Financeiro — segunda via": "Olá, preciso da segunda via do boleto da minha fatura.",
    "Suporte — acesso bloqueado": "Meu acesso está bloqueado e não consigo trabalhar. Preciso de ajuda urgente.",
    "Reclamação — cancelamento": "Estou muito insatisfeito com a cobrança indevida e quero cancelar.",
    "Logística — pedido atrasado": "Meu pedido está atrasado e gostaria de rastrear a entrega.",
    "Solicitar atendente": "Quero falar com uma pessoa, por favor."
}
choice = st.selectbox("Carregar um exemplo", ["Digite sua própria transcrição"] + list(examples.keys()))
default_text = examples.get(choice, "")
transcript = st.text_area("Transcrição da chamada", value=default_text, height=150, placeholder="Ex.: Olá, gostaria de ajuda com minha fatura...")
audio = st.file_uploader("Ou anexe um áudio para demonstrar a entrada (MP3/WAV/M4A)", type=["mp3","wav","m4a"])
if audio:
    st.info(f"Arquivo recebido: {audio.name}. Nesta versão, o áudio não é transcrito automaticamente; cole a transcrição no campo acima. A integração com serviço de speech-to-text pode ser adicionada.")

if st.button("Analisar chamada", type="primary", use_container_width=True):
    if not transcript.strip():
        st.warning("Digite ou selecione uma transcrição antes de analisar.")
    else:
        sentiment, department, priority, answer = analyze(transcript)
        st.session_state["result"] = {
            "transcript": transcript, "sentiment": sentiment,
            "department": department, "priority": priority, "answer": answer,
            "time": datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        }

if "result" in st.session_state:
    r = st.session_state["result"]
    st.divider()
    st.subheader("2. Resultado da análise")
    a,b,c = st.columns(3)
    a.metric("Sentimento identificado", r["sentiment"])
    b.metric("Setor recomendado", r["department"])
    c.metric("Prioridade", r["priority"])
    st.markdown("**Transcrição analisada**")
    st.info(r["transcript"])
    st.markdown("**Resposta automática sugerida**")
    st.success(r["answer"])
    st.markdown("**Próxima ação**")
    if r["department"] == "Atendimento humano" or "Não encontrei" in r["answer"] or r["priority"] == "Alta":
        st.warning(f"Encaminhar para: **{r['department']}** — prioridade **{r['priority']}**. Um atendente deve revisar o caso.")
    else:
        st.success(f"Enviar resposta automática e registrar atendimento no setor **{r['department']}**. Permitir transferência para humano se o cliente solicitar.")
    st.caption(f"Análise realizada em {r['time']} · Resultado demonstrativo, sujeito à validação humana.")

with st.expander("Como esta demonstração funciona?"):
    st.markdown("""
    1. **Entrada:** recebe o texto transcrito da conversa.
    2. **Análise:** identifica palavras-chave, sentimento aproximado e sinais de urgência.
    3. **Intenção e roteamento:** associa o assunto ao setor mais provável.
    4. **Resposta:** consulta uma pequena base de perguntas frequentes e sugere uma resposta.
    5. **Escalonamento:** casos urgentes, negativos ou sem resposta segura são direcionados a uma pessoa.

    **Limitações:** classificação por palavras-chave, sem modelo de IA treinado; não há telefonia real, gravação, transcrição automática nem integração com CRM nesta versão. Não use dados pessoais reais.
    """)

st.caption("Projeto acadêmico • Protótipo funcional • VozIA")
